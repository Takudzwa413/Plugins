<?php
/*
Plugin Name: Hide Login Page Outside Cape Town
Plugin URI: https://example.com/
Description: Hide the login page if the user is not in Cape Town
Version: 1.0
Author: Your Name
Author URI: https://example.com/
*/

function hide_login_outside_capetown() {
    // Get the user's IP address
    $user_ip = $_SERVER['REMOTE_ADDR'];
    
    // Get the user's location using an IP geolocation service
    $url = "https://ipgeolocation.abstractapi.com/v1/?api_key=YOUR_API_KEY&ip_address={$user_ip}";
    $response = wp_remote_get($url);
    $location_data = json_decode(wp_remote_retrieve_body($response), true);
    $user_location = $location_data['city'];
    
    // If the user is not in Cape Town, redirect them to the home page
    if ($user_location !== 'Cape Town') {
        wp_redirect(home_url());
        exit;
    }
}

add_action('login_init', 'hide_login_outside_capetown');